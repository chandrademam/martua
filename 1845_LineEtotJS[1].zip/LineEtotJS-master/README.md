Line Etot JS

# require node >= v8.x.x
check your nodejs version
`node -v`
[upgrade nodejs](https://google.com/)


How to run ?
------
- `git clone https://github.com/rivaimunte/LineEtotJS.git`
- `cd LineEtotJS && npm install`
- `npm start`

New
-------
- Msg
- Mute
- Unmute
- Add Staff
- Deleted Staff

Note
-------
- Jangan Perjual Belikan Script Ini!
- Ini Alphat Lama Tapi Di Upgrade
- Gunakan Script Ini Dengan Bijak!

Still work :construction_worker:
----
**TODO** features
- Implement All 
- Improve logic

Author
------
[@rivaimunte](http://line.me/ti/p/~kobe2k17)
